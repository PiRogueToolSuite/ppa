.. -*- coding: utf-8 -*-

:mod:`misc` - Miscellaneous helpers
-----------------------------------

Functions
~~~~~~~~~

.. automodule:: pyftdi.misc
   :members:

