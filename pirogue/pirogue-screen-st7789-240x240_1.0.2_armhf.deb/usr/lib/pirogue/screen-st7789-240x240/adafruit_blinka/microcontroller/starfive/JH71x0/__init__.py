"""Definition for the StarFive JH71x0 chip"""
