# New canonical package, to support `import rpi_ws281x`
from .rpi_ws281x import PixelStrip, Adafruit_NeoPixel, Color, ws
from _rpi_ws281x import *

__version__ = '4.3.4'
